package com.app.pojos;

public enum OrderStatus {
	PLACED,PACKING,READY,OUT_FOR_DELIVERY,DELIVERED,CANCELLED
}
